###files###
1. getGraphs.py
   This file lets me get the large number of nodes graph, and did not relate to kruskal's algo.

2. kru0.txt~kru9.txt
   10 examples of graphs, kru9.txt has 100 nodes as required.

3. kruskal.py
   Main code

4. outcome.txt
   Outcome from 10 graphs

###How to run my code###

python kruskal.py kru0.txt
(argument from kru0.txt~kru9.txt)

