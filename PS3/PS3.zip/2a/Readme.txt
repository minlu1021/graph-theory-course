##run code##

python topology.py


#################
It will output a outcome txt file which is already in the folder.
In the file, it has all the topologies in the 4 nodes point set.