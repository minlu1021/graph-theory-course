####files####
1. getExamples.py
   generate 100 nodes example, nothing to do with main code

2. dijkstra.py
   main code for dijkstra algorithm

3. dij0.txt~dij9.txt
   10 examples of weighted graph (dij8 and dij9 has 100 nodes as required!)

4. output_dij0.txt~output_dij9.txt
   output text files for 10 graphs

#### how to run my code ####

python dijkstra.py dij*.txt 
                 (* should be digit from 0 to 9)

#### Note ####

If you would like to change the start and end node of a graph, you can change the last two
lines in the dij*.txt text files.