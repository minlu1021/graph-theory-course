#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 20 13:42:08 2017

@author: chenshou
"""

#P3_3_generateTreeFromPrufer
# read from output file
import json
prufer_list = json.load(open("Tree10_node100_output.txt"))
def pruferCode2Tree(prufer_list):
    n = len(prufer_list)+2
    tree = []
    for i in range(n):
        tree.append([])
    degree = [1 for x in range(n)]
    for v in prufer_list:
        degree[v]+=1
    ptr = 0
    while degree[ptr] != 1:
        ptr+=1
    leaf = ptr
    for v in prufer_list:
        tree[leaf].append(v)
        tree[v].append(leaf)
        degree[leaf]-=1
        degree[v]-=1
        if degree[v]==1 and v<ptr:
            leaf = v
        else:
            ptr+=1
            while ptr<n and degree[ptr] != 1:
                ptr+=1
            leaf = ptr
    for v in range(0, n-1):
        if degree[v] == 1:
            tree[v].append(n-1)
            tree[n-1].append(v)
    return tree


json.dump(dict(enumerate(pruferCode2Tree(prufer_list))), open("Prufer10_node100_output.txt",'w'))