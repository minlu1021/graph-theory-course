#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 20 11:07:25 2017

@author: chenshou
"""

#P3_3 generate Prufer code from Tree

#Read from file first
import json
Tree_dict = json.load(open("Tree1_node4.txt"))
Tree_list = list(Tree_dict.values())
def Tree2PruferCode(Tree):
    n = len(Tree)
    parent = [0 for x in range(n)]
    parent[n-1] = -1
    pruferDfs(Tree, parent, n-1)
    degree = [0 for x in range(n)]
    ptr = -1
    for i in range(0,n):
        degree[i] = len(Tree[i])
        if degree[i] == 1 and ptr == -1:
            ptr = i
    res = [0 for x in range(n-2)]
    leaf = ptr
#    print(parent)
#    print(degree)
    for i in range(0, n-2):
#        print(leaf)
        next1 = parent[leaf]
        res[i] = next1
        degree[next1] -= 1
        if degree[next1]==1 and next1 < ptr:
            leaf = next1
        else:
            ptr+=1
            while ptr<n and degree[ptr]!= 1:
                ptr+=1
            leaf = ptr
    return res


def pruferDfs(tree, parent, v):
    for i in range(0, len(tree[v])):
        to = tree[v][i]
        if to != parent[v]:
            parent[to] = v
            pruferDfs(tree, parent, to)

json.dump(Tree2PruferCode(Tree_list), open("Prufer1_node4.txt",'w'))
