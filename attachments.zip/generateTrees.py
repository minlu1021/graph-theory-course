#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 20 11:08:11 2017

@author: chenshou
"""

#Create Random Tree
import random
def getRandomTree(n, rnd):
    t = []
    for i in range(0, n, 1):
        t.append([])
    p = []
    for i in range(0,n):
        p.append(0)
    
    for i in range(0,n):
        j = rnd.randint(0,i)
        p[i] = p[j]
        p[j] = i
    
    for i in range(1, n):
        parent = p[rnd.randint(0,i-1)]
        t[parent].append(p[i])
        t[p[i]].append(parent)
    return t

Tree = (getRandomTree(4,random))
Dict_T = dict(enumerate(Tree))


import json
json.dump(Dict_T, open("Tree1_node4.txt",'w'))
        